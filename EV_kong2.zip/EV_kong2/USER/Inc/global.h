#ifndef __GLOBAL_H
#define __GLOBAL_H

#include "main.h"

#define FRAME_HEADER_1 0x5A
#define FRAME_HEADER_2 0xA5
#define CMD_LED_SWITCH 0x01
#define CMD_LED_BRIGHT 0x02 


extern uint8_t rx_buf[256];
extern uint8_t write_idx;
extern uint8_t read_idx;


void handleByte(void);
void keyScan();
void sendUpFrame(void);
#endif