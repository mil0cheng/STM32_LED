#include "main.h"
#include "global.h"
#include "tim.h"
#include "usart.h"

typedef enum{
	WAIT_HEADER_1 = 0,
	WAIT_HEADER_2,
	WAIT_CMD,
	WAIT_DATA,
	WAIT_CHECK
}rx_State_m;

typedef union{
	float value;
	uint8_t types[4];
}floatType_u;

rx_State_m now_state = 0;
uint8_t checksum = 0;
uint8_t data_len = 0;
uint8_t data_buf[5] = {0};
uint8_t i = 1;

uint8_t is_led_on = 0;


uint8_t readByte(uint8_t* data){
	if(read_idx == write_idx){
		return 0;
	}
	
	*data = rx_buf[read_idx];
	
	read_idx = (read_idx+1)%256;
	
	return 1;
}
	
void workAchieve(uint8_t buf[5]){
	
	if(buf[0] == CMD_LED_SWITCH){
		
		uint8_t action = buf[1];
        if (action == 0x00) {
            //关闭 LED
				is_led_on = 0;
				HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);	
					
        } else if (action == 0x01) {
            //开启 LED
					is_led_on = 1;
					HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
					__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1,500);
					
        } else if (action == 0x02) {
            //反转 LED 状态
					if (is_led_on) {
             
                HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);	
            } else {

                HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
								__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1,500);
            }
					is_led_on = !is_led_on;
        }
    }
	else if(buf[0] == CMD_LED_BRIGHT){
		floatType_u u;
		
		u.types[0] = buf[1];
		u.types[1] = buf[2];
		u.types[2] = buf[3];
		u.types[3] = buf[4];
		
		float bright = u.value;
		int bright_value = (int)(bright*999);
		
		__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1,bright_value);
		
	}
}
		

	
void handleByte(void){
	uint8_t data = 0;
	
	if(!readByte(&data)) return;

	switch(now_state){
		
		case WAIT_HEADER_1:
			if(data == FRAME_HEADER_1){
				
				now_state = WAIT_HEADER_2;
				
			}
			
			break;
			
		case WAIT_HEADER_2:
			if(data == FRAME_HEADER_2){
				
				now_state = WAIT_CMD;
				
			}
			else{
				
				now_state = WAIT_HEADER_1;
				
			}
				
			break;	
			
		case WAIT_CMD:

			if(data == CMD_LED_SWITCH) {
                data_len = 1;
                now_state = WAIT_DATA;
								data_buf[0] = CMD_LED_SWITCH;
								i = 1;
      }
			else if(data == CMD_LED_BRIGHT){
								data_len = 4;	
								now_state = WAIT_DATA;
								data_buf[0] = CMD_LED_BRIGHT;
								i = 1;
			}
			else{
				now_state = WAIT_HEADER_1;
				i = 1;
				
			}
			
			break;
			
		case WAIT_DATA:
				
			data_buf[i] = data;
			i++;
		
		if(i >= data_len+1){
			now_state = WAIT_CHECK;
			i = 1;
		}
			
		break;	
		
		case WAIT_CHECK:
			if(data_buf[0] == CMD_LED_SWITCH){
				
				checksum = FRAME_HEADER_1+FRAME_HEADER_2+CMD_LED_SWITCH+data_buf[1];
			}
			else{

				checksum = FRAME_HEADER_1+FRAME_HEADER_2+CMD_LED_BRIGHT+data_buf[1]+data_buf[2]+data_buf[3]+data_buf[4];
			}
			
			
			if(checksum == data){
				//数据通过
				now_state = WAIT_HEADER_1;
				
				workAchieve(data_buf);
				
			}
			else{
				now_state = WAIT_HEADER_1;
			}
			
			break;	


		}
	}
				

void keyScan(){
	if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0)== GPIO_PIN_RESET){
			HAL_Delay(10);
			if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0)== GPIO_PIN_RESET){
				
				HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
				while(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_RESET);
			}
			
	}
}
	
	
void sendUpFrame(void){
    uint8_t tx_buf[4];
    
    tx_buf[0] = FRAME_HEADER_1;
    tx_buf[1] = FRAME_HEADER_2;
    
    if(HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_SET){
			
        tx_buf[2] = 0x01;
    }else{
        tx_buf[2] = 0x00;
    }
    
    tx_buf[3] = tx_buf[0] + tx_buf[1] + tx_buf[2];
    
    HAL_UART_Transmit(&huart1, tx_buf, 4, 100);
}				
